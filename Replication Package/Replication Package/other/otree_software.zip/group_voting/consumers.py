# from channels import Group
import json
from django.db import models
from django.db import transaction
import threading
import time
import datetime
from django.utils import timezone
from django.forms.models import model_to_dict


# from channels import Group
import json
from django.db import transaction
import otree.channels.utils as channel_utils
from django.conf import settings
from channels.generic.websocket import (
    JsonWebsocketConsumer, WebsocketConsumer)
ALWAYS_UNRESTRICTED = 'ALWAYS_UNRESTRICTED'
UNRESTRICTED_IN_DEMO_MODE = 'UNRESTRICTED_IN_DEMO_MODE'

import logging
logger = logging.getLogger(__name__)

from otree.common import (
    get_models_module
)
from asgiref.sync import async_to_sync


#  Copied from otree.channels.consumers.py - where Chris asks not to directly subclass but rather copy this over
#  It provides a basic implementation of a consumer with several functions to be defined by the implementing class
class _OTreeJsonWebsocketConsumer(JsonWebsocketConsumer):
    '''
    THIS IS NOT PUBLIC API.
    Third party apps should not subclass this.
    Either copy this class into your code,
    or subclass directly from JsonWebsocketConsumer,
    '''

    def group_send_channel(self, type: str, groups=None, **event):
        print('in group_send_channel')
        for group in (groups or self.groups):
            channel_utils.sync_group_send(group, {'type': type, **event})
            #print('call_args', channel_utils.sync_group_send.call_args)
            #assert channel_utils.sync_group_send.call_args

    def clean_kwargs(self, **kwargs):
        '''
        subclasses should override if the route receives a comma-separated params arg.
        otherwise, this just passes the route kwargs as is (usually there is just one).
        The output of this method is passed to self.group_name(), self.post_connect,
        and self.pre_disconnect, so within each class, all 3 of those methods must
        accept the same args (or at least take a **kwargs wildcard, if the args aren't used)
        '''
        return kwargs

    def group_name(self, **kwargs):
        raise NotImplementedError()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.cleaned_kwargs = self.clean_kwargs(**self.scope['url_route']['kwargs'])
        self.groups = self.connection_groups()

    def connection_groups(self, **kwargs):
        group_name = self.group_name(**self.cleaned_kwargs)
        return [group_name]

    unrestricted_when = ''

    # there is no login_required for channels
    # so we need to make our own
    # https://github.com/django/channels/issues/1241
    def connect(self):
        # need to accept no matter what, so we can at least send
        # an error message
        self.accept()

        AUTH_LEVEL = settings.AUTH_LEVEL

        auth_required = (
            (not self.unrestricted_when) and AUTH_LEVEL
            or
            self.unrestricted_when == UNRESTRICTED_IN_DEMO_MODE and AUTH_LEVEL == 'STUDY'
        )

        if auth_required and not self.scope['user'].is_staff:
            msg = 'rejected un-authenticated access to websocket'
            logger.warning(msg)
            # it's good to send an explanation so we understand e.g.
            # test failures
            self.send_json({'unauthenticated_websocket': msg})
            return
        else:
            self.post_connect(**self.cleaned_kwargs)

    def post_connect(self, **kwargs):
        pass

    def disconnect(self, message, **kwargs):
        self.pre_disconnect(**self.cleaned_kwargs)

    def pre_disconnect(self, **kwargs):
        pass

    def receive_json(self, content, **etc):
        self.post_receive_json(content, **self.cleaned_kwargs)

    def post_receive_json(self, content, **kwargs):
        pass


# Extend the copied-over _OTreeJsonWebsocketConsumer by implementing:
#   clean_kwargs - parses the arguments passed in the channel URL
#   group_name - constructs a unique group name for the channel_layer
#   post_connect - adds player to a channel_layer and performs any actions needed upon connecting a client
#   pre_disconnect - performs any actions needed after a player disconnects, and removes them from the channel_layer
#   post_receive_json - performs the actions required when receiving a message
#
#   You also need one more function to parse messages of each "type" you expect sent over the channels (in this case:  channelsmin_message()
class GroupVotingConsumer(_OTreeJsonWebsocketConsumer):

    unrestricted_when = ALWAYS_UNRESTRICTED

    # parse the parameters passed in the websockets URL and return a dict with name: value pairs
    def clean_kwargs(self, params):
        group_id, player_id, session_code = params.split(',')
        return {
            'group_id': int(group_id),
            'session_code': session_code,
            'player_id': int(player_id)
        }

    # return a unique group_name for the channel_layer so that each oTree group gets its own channel_layer
    def group_name(self, group_id, session_code, player_id):
        return "channel_group_voting_session-" + str(session_code) + "_group-" + str(group_id)

    # parse messages of type channelsmin_message
    def groupvoting_message(self, event):
        # Send message to WebSocket
        self.send(text_data=json.dumps(
            event
        ))

    # perform actions neccesary to add a subject to their group's channel_layer.  In our case, if a group has already ended
    # we need to send them a message saying that, so that they can go to the end page too
    def post_connect(self, group_id, session_code, player_id):
        # add them to the channel_layer
        self.room_group_name = self.group_name(group_id, session_code, player_id)
        async_to_sync(self.channel_layer.group_add)(
            self.room_group_name,
            self.channel_name
        )

        # print("group name is: "+get_group_name(group_id, session_id))
        with transaction.atomic():
            models_module = get_models_module('group_voting')
            group_object = models_module.Group.objects.select_for_update().get(id=group_id)

            print("session=" + str(session_code) + ", adding player with id=" + str(player_id))
            print("group_object.id=" + str(group_object.id) + ", round_number=" + str(
                group_object.round_number) + ", decision_start_time=" + str(group_object.decision_start_time))

            if player_id in group_object.connected.split(','):
                print("TRYING TO ADD PLAYER (" + str(player_id) + ") WHO IS ALREADY IN CONNECTED LIST (" + str(
                    group_object.connected))

            # group_object.num_connected = group_object.num_connected+1
            group_object.connected = group_object.connected + str(player_id) + ','
            group_object.num_connected = len(group_object.connected.split(',')) - 1
            group_object.save()
            print("time=" + str(datetime.datetime.now()) + ", group_object.num_connected=" + str(
                group_object.num_connected) + ", starttime=" + str(
                group_object.decision_start_time) + ", connected=" + str(group_object.connected))
            if group_object.num_connected == models_module.Constants.players_per_group and group_object.decision_start_time == None:
                group_object = models_module.Group.objects.select_for_update().get(id=group_id)
                group_object.decision_start_time = datetime.datetime.utcnow()
                group_object.save()
                print("setting group_object.decision_start_time to: " + str(group_object.decision_start_time))

                state = {}
                state['type'] = 'groupvoting_message'
                state['message_type'] = 'start_clock'
                # group.send(
                #     {'text': json.dumps(state)}
                # )
                # send the message
                async_to_sync(self.channel_layer.group_send)(
                    self.room_group_name,
                    state
                )


            elif (group_object.decision_start_time != None):
                print("sending reconnect message! - initial_local_clock_time=" + str(
                    group_object.get_player_by_id(player_id).initial_local_clock_time))
                state = {}
                state['player_positions'] = group_object.player_positions
                state['start_clock'] = "True"
                if group_object.get_player_by_id(player_id).initial_local_clock_time != '':
                    print("sending player's own local start time...");
                    state['init_time'] = str(group_object.get_player_by_id(player_id).initial_local_clock_time)
                else:
                    print(
                        "sending decision_start_time=" + str(int(group_object.decision_start_time.timestamp() * 1000)))
                    state['init_time'] = str(int(group_object.decision_start_time.timestamp()) * 1000)
                    print("no player init time, approximating from decision_start_time, setting state[init_time] to: " +
                          state['init_time'])
                if group_object.subsession.use_individual_decision:
                    state['type'] = 'individual_reconnect'
                    player_object = group_object.get_player_by_id(player_id)
                    print("individual reconnect!   testing player_object.move_values=" + str(player_object.move_values))
                    if (not group_object.subsession.use_static_sampling) and player_object.move_values != '':
                        print("sending individual reconnect message! ")
                        state['move'] = player_object.move_values
                        state['move_clicks'] = player_object.move_clicks
                        state['start_clock'] = "False"
                else:
                    state['type'] = 'groupvoting_message'
                    state['message_type'] = 'reconnect'
                    move_list = group_object.player_positions.split(',')
                    a_count = 0
                    b_count = 0
                    for move in move_list:
                        if move == 'A':
                            a_count += 1
                        elif move == 'B':
                            b_count += 1
                    print("a_count==" + str(a_count) + ",b_count=" + str(b_count))
                    if a_count >= group_object.subsession.votes_to_win or b_count >= group_object.subsession.votes_to_win:
                        state['group_time'] = group_object.final_tick
                        if a_count >= group_object.subsession.votes_to_win:
                            state['group_choice'] = 'A'
                        else:
                            state['group_choice'] = 'B'
                        state['end'] = "True"
                        state['start_clock'] = "False"

                self.send_json(state)


    # perform any actions necessary before removing a subject from the channel_layer.  In our case there's nothing to do but
    # discard them from the channel layer
    def pre_disconnect(self, group_id, session_code, player_id):

        models_module = get_models_module('group_voting')

        with transaction.atomic():
            group_object = models_module.Group.objects.select_for_update().get(id=group_id)
            print("disconnecting player_id=" + str(player_id) + ", old connected=" + str(group_object.connected))
            group_object.connected = group_object.connected.replace((str(player_id) + ','), '')
            print("disconnecting player_id=" + str(player_id) + ", new connected=" + str(group_object.connected))
            # group_object.num_connected -= 1
            group_object.num_connected = len(group_object.connected.split(',')) - 1
            print(
                "disconnecting player_id=" + str(player_id) + ", new num_connected=" + str(group_object.num_connected))
            group_object.save()

        # remove the player from their channel_layer
        self.room_group_name = self.group_name(group_id, session_code, player_id)
        async_to_sync(self.channel_layer.group_discard)(
            self.room_group_name,
            self.channel_name
        )




    # handle non-connect and non-disconnect messages.  We only expect one message, one with the 'message' of 'done'
    # When we receive that, update the group object's "firstpage_done" field to True, save it to the db, and send a
    # message to the rest of the channel_layer telling them we're done
    def post_receive_json(self, content, group_id, session_code, player_id):

        message_type = content['message_type']

        models_module = get_models_module('group_voting')

        print(
            "ws_receive called.  type==" + str(message_type) + "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*")
        # print("ws_receive called.  type="+str(message_type)+", offerer = "+str(content['offerer'])+", -----"+str(content['offer']+"-----> receiver= "+str(content['offerto'])))
        # print("ws_receive, received message, type=" + message_type + ", player_id=" + str(player_id) + ", group_id=" + str(
        #    group_id) + ", player_id=" + str(player_id) + ", group_object.round_number=" + str(group_object.round_number)+
        #      ", group_object.finished="+str(group_object.finished))
        # print("")
        if message_type == 'move':
            with transaction.atomic():
                print("\"move\" message received.  value=" + str(content['value']) + ", click = " + str(
                    content['click']) + ", time = " + str(content['time']))
                group_object = models_module.Group.objects.select_for_update().get(id=group_id)
                move_value = content['value']
                move_click = content['click']
                move_initial_time = content['initial_time']
                move_time = content['time']

                if not group_object.finished:

                    player_object = group_object.get_player_by_id(player_id)
                    # player_object = models_module.Player.objects.select_for_update().get(id_in_session=player_id)
                    player_object.move_values = player_object.move_values + "," + move_value
                    player_object.move_clicks = player_object.move_clicks + "," + move_click
                    player_object.move_local_times = player_object.move_local_times + "," + move_time
                    if player_object.initial_local_clock_time == '':
                        player_object.initial_local_clock_time = move_initial_time
                    player_object.save()

                    move_list = group_object.player_positions.split(',')
                    move_list[player_id] = move_value
                    print("player_id=" + str(player_id) + ", move=" + move_value + ", updated move_list=" + str(
                        move_list) + ", updated move_clicks=" + str(player_object.move_clicks))
                    group_object.player_positions = ','.join(map(str, move_list))
                    group_object.final_tick = int(move_click)
                    print("group_object.player_positions=" + str(group_object.player_positions))

                    state = {}
                    state['type'] = 'groupvoting_message'
                    state['message_type'] = 'state'
                    state['player_positions'] = group_object.player_positions

                    a_count = 0
                    b_count = 0
                    for move in move_list:
                        if move == 'A':
                            a_count += 1
                        elif move == 'B':
                            b_count += 1
                    print("a_count==" + str(a_count) + ",b_count=" + str(b_count))

                    if (not group_object.subsession.use_individual_decision) and (
                            a_count >= group_object.subsession.votes_to_win or b_count >= group_object.subsession.votes_to_win):
                        state['end'] = 'True'
                        if a_count >= group_object.subsession.votes_to_win:
                            state['group_choice'] = 'A'
                        else:
                            state['group_choice'] = 'B'
                        state['group_time'] = move_click
                        print("state[\'group_time\']=" + state['group_time'])
                        group_object.finished = True
                    else:
                        state['end'] = 'False'
                    group_object.save();

                    # send the click to the other players in the group
                    if not group_object.subsession.use_individual_decision:
                        # Group(get_group_name(group_id, session_code)).send(
                        #     {'text': json.dumps(state)}
                        # )
                        async_to_sync(self.channel_layer.group_send)(
                            self.room_group_name,
                            state
                        )


def decision_time_left(group_id):
    models_module = get_models_module('group_voting')
    group_object = models_module.Group.objects.get(id=group_id)

    time_left = group_object.subsession.decision_time_limit_seconds - (timezone.now() - group_object.decision_start_time).seconds
    # print("decision_time_left returning " + str(time_left))
    return time_left if time_left > 0 else 0