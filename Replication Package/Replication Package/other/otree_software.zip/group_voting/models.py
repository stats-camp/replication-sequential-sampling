# -*- coding: utf-8 -*-
# <standard imports>
from __future__ import division
from otree.db import models
from otree.constants import BaseConstants
from otree.models import BaseSubsession, BaseGroup, BasePlayer
from otree.db.models import Model, ForeignKey
#from group_voting.consumers import tick
import threading
import json
import csv
from math import exp, floor
from django.utils import timezone
import datetime
from statistics import median

from otree import widgets
from otree.common import Currency as c, currency_range
import random
from django.db import models as django_models
# </standard imports>


doc = """
In the asymmetric matrix game, the strategy sets for both players are
different.
"""


class Constants(BaseConstants):
    name_in_url = 'group_voting'
    players_per_group = 3
    num_rounds = 32

class Subsession(BaseSubsession):

    process_number = models.IntegerField(initial=-1)
    state = models.IntegerField(initial=-1)
    votes_to_win = models.IntegerField(initial=0)
    use_linear_costs = models.BooleanField(initial=False)
    use_individual_decision = models.BooleanField(initial=False)
    tick_interval_milliseconds = models.IntegerField(initial=200)
    tick_maximum_before_reset = models.IntegerField(initial=500)
    use_static_sampling = models.BooleanField(initial=False)

    paying_round = models.IntegerField(initial=-1)

    def creating_session(self):
        print("creating_session called for subsession.round_number=" + str(self.round_number))
        # print("num_processes="+str(Constants.num_processes)+", processes[0]="+str(Constants.processes[0]))

        if self.round_number == 1:
            # create a map from round numbers to a boolean showing whether it's a paid round or not
            # pick 20 of the 30 rounds (from 3-32) to pay on
            self.session.vars['paying_rounds'] = []
            rounds_list = list(range(3,33))
            for count in range(1,21):
                random_pick = random.choice(rounds_list)
                self.session.vars['paying_rounds'].append(random_pick)
                rounds_list.remove(random_pick)
                print("randomly picked "+str(random_pick)+", new paying rounds="+str(self.session.vars['paying_rounds'])+", new rounds_list="+str(rounds_list))

            #print("creating_session called (round_number==1), decision_start_time="+str(self.decision_start_time))

        self.paying_round = self.round_number in self.session.vars['paying_rounds']
        print("round "+str(self.round_number)+", self.paying_round="+str(self.paying_round))

        self.group_randomly()



        # if self.round_number == 1:
        #     process_list = [1,2]
        #     remainder = list(range(3,len(states)+1))
        #     for counter in range(Constants.num_rounds-2):
        #         print("remaining options: " + str(remainder))
        #         random_entry = random.choice(remainder)
        #         remainder.remove(random_entry)
        #         process_list.append(random_entry)
        #         print("new process_list="+str(process_list))
        #     self.session.vars['process_list'] = process_list


        if 'process_number' in self.session.config:
            process_numbers = self.session.config['process_number']
            print("process_numbers="+str(process_numbers))
            process_list = process_numbers.split(',')
        # process_list = self.session.vars['process_list']
        self.process_number = int(process_list[self.round_number-1])
        print("process chosen for round number "+str(self.round_number)+" is: "+str(self.process_number))

        with open('group_voting/static/input_states.csv') as f:
            states = list(csv.reader(f))
            print("states = "+str(states))
            print("states["+str(self.process_number)+"]="+str(states[self.process_number-1]))
        self.state = int(states[self.process_number][0])
        print("states="+str(states))
        print("self.state="+str(self.state))


        if 'votes_to_win' in self.session.config:
            self.votes_to_win = self.session.config['votes_to_win']
        if 'use_linear_costs' in self.session.config:
            self.use_linear_costs = self.session.config['use_linear_costs']
        if 'use_individual_decision' in self.session.config:
            self.use_individual_decision = self.session.config['use_individual_decision']
        if 'tick_interval_milliseconds' in self.session.config:
            self.tick_interval_milliseconds = self.session.config['tick_interval_milliseconds']
        if 'tick_maximum_before_reset' in self.session.config:
            self.tick_maximum_before_reset = self.session.config['tick_maximum_before_reset']
        if 'use_static_sampling' in self.session.config:
            self.use_static_sampling = self.session.config['use_static_sampling']



        for g in self.get_groups():
            g.init_states()
            for p in g.get_players():
                # print("p.id_in_group=" + str(p.id_in_group) + ", role=" + str(
                #     p.role()) + ", p.participant.id_in_session" + str(p.participant.id_in_session))
                if 'v_a_'+str(p.id_in_group) in self.session.config:
                    p.v_a = self.session.config['v_a_'+str(p.id_in_group)]
                    # print("player "+str(p.id_in_group)+", set v_a to: "+str(p.v_a))
                if 'v_b_'+str(p.id_in_group) in self.session.config:
                    p.v_b = self.session.config['v_b_'+str(p.id_in_group)]
                    #print("player " + str(p.id_in_group) + ", set v_b to: " + str(p.v_b))
                if 'discount_'+str(p.id_in_group) in self.session.config:
                    p.discount = self.session.config['discount_'+str(p.id_in_group)]
                    #print("player " + str(p.id_in_group) + ", set discount to: " + str(p.discount))
        print("creating_session ending.")

    def vars_for_admin_report(self):
        rval = {}

        rval['num_rounds'] = self.round_number
        rval['num_groups'] = len(self.get_groups())
        return {
            'data_js_vars': json.dumps(rval)
        }


class Group(BaseGroup):
    decision_start_time = django_models.DateTimeField(null=True)
    player_positions = models.StringField(initial='!!,W,W,W')
    num_connected = models.IntegerField(initial=0)
    connected = models.StringField(initial='')
    current_tick = models.IntegerField(initial=0)
    group_decision = models.StringField(initial='')
    final_tick = models.IntegerField(initial=0)
    group_static_decision = models.IntegerField(min=0, max=300)
    finished = models.BooleanField(initial=False)

    def init_states(self):
        print("init_states called... self.round_number=" + str(self.round_number))
        count = 0

        # for a in Constants.type_a_names:
        #     for b in Constants.type_b_names:
        #         # print("trying to create state for a=" + str(a) + ", b=" + str(b))
        #         state = self.cellstate_set.create()
        #         state.type_a_name = a
        #         state.type_b_name = b
        #         state.a_pay = matrix_role_a[a][b]
        #         state.b_pay = matrix_role_b[b][a]
        #         state.session_id = self.session.code
        #         state.round_number = self.round_number
        #         state.save()
        #         print("saving state.  state.group_id=" + str(state.group_id) + ", state.round_number=" + str(
        #             state.round_number))
        #         count = count + 1
        #         # print("... " + str(count) + " entries added to db with session_id=" + str(self.session.code))
        #         # self.decision_inactivity_time = timezone.now()

    def set_static_payoffs(self):
        print("set_static_payoffs called, self.player_positions="+str(self.player_positions))
        move_list = self.player_positions.split(',')
        a_count = 0
        b_count = 0
        w_count = 0
        for move in move_list:
            if move == 'A':
                a_count += 1
            elif move == 'B':
                b_count += 1
            elif move == 'W':
                w_count += 1
        print("a_count==" + str(a_count) + ",b_count=" + str(b_count))


        # read in the process sequences
        with open('group_voting/static/input_data.csv') as f:
            processes = list(csv.reader(f))
        num_processes = len(processes)
        for i in range(len(processes)):
            for j in range(len(processes[i])):
                processes[i][j] = float(processes[i][j])

        process = processes[self.subsession.process_number]

        if self.subsession.use_individual_decision:
            print("Static Sampling -> Individual Decision payoffs:")
            for p in self.get_players():
                print("p.static_decision="+str(p.static_decision))
                tick_num = floor(p.static_decision*1000/self.subsession.tick_interval_milliseconds)
                p.individual_decision = None
                if process[tick_num] == 0.5:
                    if random.random() < 0.5:
                        p.individual_decision = 'A'
                    else:
                        p.individual_decision = 'B'
                    print("randomly choosing individual decision: value="+str(p.individual_decision))
                elif process[tick_num] > 0.5:
                    p.individual_decision = 'A'
                elif process[tick_num] < 0.5:
                    p.individual_decision = 'B'

                if p.individual_decision == 'A':
                    if self.subsession.state == 0:
                        p.potential_payoff = p.payoff_function(tick_num*(self.subsession.tick_interval_milliseconds/1000), p.v_a, p.discount)
                    else:
                        p.potential_payoff = p.payoff_function(tick_num*(self.subsession.tick_interval_milliseconds/1000), 0, p.discount)
                elif p.individual_decision == 'B':
                    if self.subsession.state == 1:
                        p.potential_payoff = p.payoff_function(tick_num*(self.subsession.tick_interval_milliseconds/1000), p.v_b, p.discount)
                    else:
                        p.potential_payoff = p.payoff_function(tick_num*(self.subsession.tick_interval_milliseconds/1000), 0, p.discount)

        else:
            print("Static Sampling -> Group Decision payoffs:")
            self.group_static_decision = 0
            times = []
            missing_decision = False
            for p in self.get_players():
                if p.static_decision is None:
                    missing_decision = True
                else:
                    times.append(p.static_decision)
            if self.subsession.votes_to_win == Constants.players_per_group:
                # use the max of the times submitted (ignore missing times)
                if len(times) > 0:
                    self.group_static_decision = max(times)
                else:
                    self.group_static_decision = random.randint(0, 60)
            else:
                # use median time
                if not missing_decision:
                    self.group_static_decision = median(times)
                else:
                    #randomly pick which one is the answer
                    if len(times)>0:
                        self.group_static_decision = random.choice(times)
                    else:
                        self.group_static_decision = random.randint(0,60)

            tick_num = floor(self.group_static_decision*1000/self.subsession.tick_interval_milliseconds)
            print("tick_num="+str(tick_num)+", process[tick_num]="+str(process[tick_num]))
            if process[tick_num] == 0.5:
                if random.random() < 0.5:
                    self.group_decision = 'A'
                else:
                    self.group_decision = 'B'
                print("randomly choosing group decision: value=" + str(self.group_decision))
            elif process[tick_num] > 0.5:
                self.group_decision = 'A'
            elif process[tick_num] < 0.5:
                self.group_decision = 'B'

            print("group_decision="+str(self.group_decision)+", state="+str(self.subsession.state))
            for player in self.get_players():
                if self.group_decision == 'A':
                    if self.subsession.state == 0:
                        print("MATCHING RESULTS A")
                        player.potential_payoff = player.payoff_function(tick_num*(self.subsession.tick_interval_milliseconds/1000), player.v_a, player.discount)
                    else:
                        player.potential_payoff = player.payoff_function(tick_num*(self.subsession.tick_interval_milliseconds/1000), 0, player.discount)
                elif self.group_decision == 'B':
                    if self.subsession.state == 1:
                        print("MATCHING RESULTS B")
                        player.potential_payoff = player.payoff_function(tick_num*(self.subsession.tick_interval_milliseconds/1000), player.v_b, player.discount)
                    else:
                        player.potential_payoff = player.payoff_function(tick_num*(self.subsession.tick_interval_milliseconds/1000), 0, player.discount)
        # print("setting payoffs: subsession.paying_round=" + str(self.subsession.paying_round))
        for player in self.get_players():
            if self.subsession.paying_round==1:
                player.payoff = player.potential_payoff * 2
            else:
                player.payoff = 0
            print("player.id_in_group " + str(player.id_in_group) + " payoff=" + str(player.payoff))

    def set_payoffs(self):
        print("set_payoffs called, self.player_positions=" + str(self.player_positions))
        move_list = self.player_positions.split(',')
        a_count = 0
        b_count = 0
        w_count = 0
        for move in move_list:
            if move == 'A':
                a_count += 1
            elif move == 'B':
                b_count += 1
            elif move == 'W':
                w_count += 1
        print("a_count==" + str(a_count) + ",b_count=" + str(b_count))

        if self.subsession.use_individual_decision:
            print("Dynamic Sampling -> Individual Decision payoffs:")
            for player in self.get_players():
                print("player.move_values="+str(player.move_values)+", move_clicks="+str(player.move_clicks))
                player.individual_decision = player.move_values.split(',')[-1]
                final_click = float(player.move_clicks.split(',')[-1])
                if player.individual_decision == 'A':
                    if self.subsession.state == 0:
                        player.potential_payoff = player.payoff_function(final_click*(self.subsession.tick_interval_milliseconds/1000), player.v_a, player.discount)
                    else:
                        player.potential_payoff = player.payoff_function(final_click*(self.subsession.tick_interval_milliseconds/1000), 0, player.discount)
                elif player.individual_decision == 'B':
                    if self.subsession.state == 1:
                        player.potential_payoff = player.payoff_function(final_click*(self.subsession.tick_interval_milliseconds/1000), player.v_b, player.discount)
                    else:
                        player.potential_payoff = player.payoff_function(final_click*(self.subsession.tick_interval_milliseconds/1000), 0, player.discount)
                print("player.potential_payoff="+str(player.potential_payoff))
        else: #group decision
            print("Dynamic Sampling -> Group Decision payoffs:")
            if w_count == 3:
                current_time = timezone.now()
                time_delta_milliseconds = (current_time - self.decision_start_time).total_seconds() * 1000
                self.final_tick = floor(time_delta_milliseconds / self.subsession.tick_interval_milliseconds)
            if not self.subsession.votes_to_win == Constants.players_per_group:
                # majority case
                if (w_count == 1 and a_count == 1 and b_count == 1) or w_count==3:
                    print("Majority, one (or three) non-respondants (with the two respondants having opposite choices), choosing randomly")
                    if random.random() < 0.5:
                        self.group_decision = 'A'
                    else:
                        self.group_decision = 'B'
                elif w_count == 2:
                    if a_count == 1:
                        print("Majority with two non-respondants and one chose A")
                        self.group_decision = 'A'
                    elif b_count == 1:
                        print("Majority with two non-respondants and one chose B")
                        self.group_decision = 'B'
                elif w_count == 0:
                    if a_count >= self.subsession.votes_to_win:
                        print("Majority with at least 2 choosing A")
                        self.group_decision = 'A'
                    elif b_count >= self.subsession.votes_to_win:
                        print("Majority with at least 2 choosing B")
                        self.group_decision = 'B'
                elif a_count == 2:
                    self.group_decision = 'A'
                elif b_count == 2:
                    self.group_decision = 'B'
            else:
                # unanimity case
                if w_count == 0:
                    if a_count >= self.subsession.votes_to_win:
                        print("Unanimity with all choosing A")
                        self.group_decision = 'A'
                    elif b_count >= self.subsession.votes_to_win:
                        print("Unanimity with all choosing B")
                        self.group_decision = 'B'
                    else:
                        print("Unanimity with *not* all choosing either - choosing randomly");
                        if random.random() < 0.5:
                            self.group_decision = 'A'
                        else:
                            self.group_decision = 'B'
                elif w_count == 1:
                    if a_count == 2:
                        print("Unanimity with one nonrespondant and the others both choosing A");
                        self.group_decision = 'A'
                    elif b_count == 2:
                        print("Unanimity with one nonrespondant and the others both choosing B");
                        self.group_decision = 'B'
                    elif a_count == 1 and b_count == 1:
                        print("Unanimity with one nonrespondant and the others disagreeing, choosing randomly");
                        if random.random() < 0.5:
                            self.group_decision = 'A'
                        else:
                            self.group_decision = 'B'
                elif w_count == 2:
                    if a_count == 1:
                        print("Unanimity with two nonrespondants and the other choosing A")
                        self.group_decision = 'A'
                    elif b_count == 1:
                        print("Unanimity with two nonrespondants and the other choosing B")
                        self.group_decision = 'B'
                elif w_count == 3:
                    print("Unanimity with three nonrespondants, choosing randomly (and setting final tick value to current time)")
                    if random.random() < 0.5:
                        self.group_decision = 'A'
                    else:
                        self.group_decision = 'B'
            print("self.group_decision="+str(self.group_decision))
            for player in self.get_players():
                if self.group_decision == 'A':
                    if self.subsession.state == 0:
                        player.potential_payoff = player.payoff_function(self.final_tick*(self.subsession.tick_interval_milliseconds/1000), player.v_a, player.discount)
                    else:
                        player.potential_payoff = player.payoff_function(self.final_tick*(self.subsession.tick_interval_milliseconds/1000), 0, player.discount)
                elif self.group_decision == 'B':
                    if self.subsession.state == 1:
                        player.potential_payoff = player.payoff_function(self.final_tick*(self.subsession.tick_interval_milliseconds/1000), player.v_b, player.discount)
                    else:
                        player.potential_payoff = player.payoff_function(self.final_tick*(self.subsession.tick_interval_milliseconds/1000), 0, player.discount)
                print("player.id="+str(player.id_in_group)+", potential_payoff="+str(player.potential_payoff))
            # unique_group_id = CellState.objects.filter(session_id=self.session.code)[0].group_id
            # print("group.session.code=" + str(self.session.code) + ", unique_group_id=" + str(
            #     unique_group_id) + ", player.group.round number=" + str(
            #     player.group.round_number) + ", self.round_number=" + str(self.round_number))
            # group_states = CellState.objects.filter(group__exact=player.group.id_in_subsession)
            # group_states = CellState.objects.filter(group__exact=self).filter(round_number=self.round_number)
            # group_states = CellState.objects.filter(group__exact=self)

        print("setting payoffs: subsession.paying_round=" + str(self.subsession.paying_round))
        for player in self.get_players():
            if self.subsession.paying_round==1:
                player.payoff = player.potential_payoff * 2
            else:
                player.payoff = 0
            print("player.id_in_group " + str(player.id_in_group) + " payoff=" + str(player.payoff))


class Player(BasePlayer):
    v_a = models.IntegerField(initial=0)
    v_b = models.IntegerField(initial=0)
    discount = models.FloatField(initial=0)

    potential_payoff = models.CurrencyField(initial=0)
    initial_local_clock_time = models.StringField(initial='')
    move_values = models.StringField(initial='')
    move_clicks = models.StringField(initial='')
    move_local_times = models.StringField(initial='')
    static_decision = models.IntegerField(min=0, max=300)
    individual_decision = models.StringField(initial='')

    def payoff_function(self, x, value, discount):

        if self.subsession.use_linear_costs:
            print("payoff_function called with x=" + str(x) + ", value=" + str(value) + ", discount=" + str(discount)+", returning linear value "+str(value-discount*x/60))
            return value - discount * x / 60;
        else:
            print("payoff_function called with x=" + str(x) + ", value=" + str(value) + ", discount=" + str(discount) + ", returning exponential value " + str(value*exp((0-discount)*x/60)))
            return value * exp((0 - discount) * x / 60)

