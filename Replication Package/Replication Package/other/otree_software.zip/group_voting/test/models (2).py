# -*- coding: utf-8 -*-
# <standard imports>
from __future__ import division
from otree.db import models
from otree.constants import BaseConstants
from otree.models import BaseSubsession, BaseGroup, BasePlayer
from otree.db.models import Model, ForeignKey
import json
from django.utils import timezone
import datetime

from otree import widgets
from otree.common import Currency as c, currency_range
import random

# </standard imports>


doc = """
In the asymmetric matrix game, the strategy sets for both players are
different.
"""


class Constants(BaseConstants):
    name_in_url = 'matrix_matching'
    players_per_group = 6
    num_rounds = 11

    type_a_names = ['Kiwi', 'Mango', 'Plum']
    type_b_names = ['Blue', 'Crimson', 'White']

    round_1_a00 = 16
    round_1_a01 = 8
    round_1_a02 = 24
    round_1_a10 = 32
    round_1_a11 = 16
    round_1_a12 = 48
    round_1_a20 = 48
    round_1_a21 = 24
    round_1_a22 = 72

    round_2_a00 = 8
    round_2_a01 = 16
    round_2_a02 = 24
    round_2_a10 = 16
    round_2_a11 = 32
    round_2_a12 = 48
    round_2_a20 = 24
    round_2_a21 = 48
    round_2_a22 = 72

    round_3_a00 = 16
    round_3_a01 = 32
    round_3_a02 = 48
    round_3_a10 = 8
    round_3_a11 = 16
    round_3_a12 = 24
    round_3_a20 = 24
    round_3_a21 = 48
    round_3_a22 = 72

    round_4_a00 = 24
    round_4_a01 = 48
    round_4_a02 = 72
    round_4_a10 = 16
    round_4_a11 = 32
    round_4_a12 = 48
    round_4_a20 = 8
    round_4_a21 = 16
    round_4_a22 = 24

    round_5_a00 = 16
    round_5_a01 = 8
    round_5_a02 = 24
    round_5_a10 = 32
    round_5_a11 = 16
    round_5_a12 = 48
    round_5_a20 = 48
    round_5_a21 = 24
    round_5_a22 = 72

    round_6_a00 = 24
    round_6_a01 = 16
    round_6_a02 = 8
    round_6_a10 = 48
    round_6_a11 = 32
    round_6_a12 = 16
    round_6_a20 = 72
    round_6_a21 = 48
    round_6_a22 = 24

    round_7_a00 = 32
    round_7_a01 = 16
    round_7_a02 = 48
    round_7_a10 = 16
    round_7_a11 = 8
    round_7_a12 = 24
    round_7_a20 = 48
    round_7_a21 = 24
    round_7_a22 = 72

    round_8_a00 = 8
    round_8_a01 = 16
    round_8_a02 = 24
    round_8_a10 = 24
    round_8_a11 = 48
    round_8_a12 = 72
    round_8_a20 = 16
    round_8_a21 = 32
    round_8_a22 = 48

    round_9_a00 = 72
    round_9_a01 = 48
    round_9_a02 = 24
    round_9_a10 = 48
    round_9_a11 = 32
    round_9_a12 = 16
    round_9_a20 = 24
    round_9_a21 = 16
    round_9_a22 = 8

    round_10_a00 = 8
    round_10_a01 = 24
    round_10_a02 = 16
    round_10_a10 = 16
    round_10_a11 = 48
    round_10_a12 = 32
    round_10_a20 = 24
    round_10_a21 = 72
    round_10_a22 = 48

    round_11_a00 = 8
    round_11_a01 = 24
    round_11_a02 = 16
    round_11_a10 = 24
    round_11_a11 = 72
    round_11_a12 = 48
    round_11_a20 = 16
    round_11_a21 = 48
    round_11_a22 = 32

    sub_round_1_a00 = 32
    sub_round_1_a01 = 8
    sub_round_1_a02 = 56
    sub_round_1_a10 = 48
    sub_round_1_a11 = 32
    sub_round_1_a12 = 64
    sub_round_1_a20 = 64
    sub_round_1_a21 = 56
    sub_round_1_a22 = 72

    sub_round_2_a00 = 8
    sub_round_2_a01 = 32
    sub_round_2_a02 = 56
    sub_round_2_a10 = 32
    sub_round_2_a11 = 48
    sub_round_2_a12 = 64
    sub_round_2_a20 = 56
    sub_round_2_a21 = 64
    sub_round_2_a22 = 72

    sub_round_3_a00 = 32
    sub_round_3_a01 = 48
    sub_round_3_a02 = 64
    sub_round_3_a10 = 8
    sub_round_3_a11 = 32
    sub_round_3_a12 = 56
    sub_round_3_a20 = 56
    sub_round_3_a21 = 64
    sub_round_3_a22 = 72

    sub_round_4_a00 = 56
    sub_round_4_a01 = 64
    sub_round_4_a02 = 72
    sub_round_4_a10 = 32
    sub_round_4_a11 = 48
    sub_round_4_a12 = 64
    sub_round_4_a20 = 8
    sub_round_4_a21 = 32
    sub_round_4_a22 = 56

    sub_round_5_a00 = 32
    sub_round_5_a01 = 8
    sub_round_5_a02 = 56
    sub_round_5_a10 = 48
    sub_round_5_a11 = 32
    sub_round_5_a12 = 64
    sub_round_5_a20 = 64
    sub_round_5_a21 = 56
    sub_round_5_a22 = 72

    sub_round_6_a00 = 56
    sub_round_6_a01 = 32
    sub_round_6_a02 = 8
    sub_round_6_a10 = 64
    sub_round_6_a11 = 48
    sub_round_6_a12 = 32
    sub_round_6_a20 = 72
    sub_round_6_a21 = 64
    sub_round_6_a22 = 56

    sub_round_7_a00 = 48
    sub_round_7_a01 = 32
    sub_round_7_a02 = 64
    sub_round_7_a10 = 32
    sub_round_7_a11 = 8
    sub_round_7_a12 = 56
    sub_round_7_a20 = 64
    sub_round_7_a21 = 56
    sub_round_7_a22 = 72

    sub_round_8_a00 = 8
    sub_round_8_a01 = 32
    sub_round_8_a02 = 56
    sub_round_8_a10 = 56
    sub_round_8_a11 = 64
    sub_round_8_a12 = 72
    sub_round_8_a20 = 32
    sub_round_8_a21 = 48
    sub_round_8_a22 = 64

    sub_round_9_a00 = 72
    sub_round_9_a01 = 64
    sub_round_9_a02 = 56
    sub_round_9_a10 = 64
    sub_round_9_a11 = 48
    sub_round_9_a12 = 32
    sub_round_9_a20 = 56
    sub_round_9_a21 = 32
    sub_round_9_a22 = 8

    sub_round_10_a00 = 8
    sub_round_10_a01 = 56
    sub_round_10_a02 = 32
    sub_round_10_a10 = 32
    sub_round_10_a11 = 64
    sub_round_10_a12 = 48
    sub_round_10_a20 = 56
    sub_round_10_a21 = 72
    sub_round_10_a22 = 64

    sub_round_11_a00 = 8
    sub_round_11_a01 = 56
    sub_round_11_a02 = 32
    sub_round_11_a10 = 56
    sub_round_11_a11 = 72
    sub_round_11_a12 = 64
    sub_round_11_a20 = 32
    sub_round_11_a21 = 64
    sub_round_11_a22 = 48

    b00 = 0
    b01 = 0
    b02 = 0
    b10 = 0
    b11 = 0
    b12 = 0
    b20 = 0
    b21 = 0
    b22 = 0


class Subsession(BaseSubsession):
    decision_start_time = models.DateTimeField()
    decision_time_limit_seconds = models.IntegerField(initial=30)
    response_time_limit_seconds = models.IntegerField(initial=10)
    a00 = models.IntegerField(initial=8)
    a01 = models.IntegerField(initial=16)
    a02 = models.IntegerField(initial=24)
    a10 = models.IntegerField(initial=16)
    a11 = models.IntegerField(initial=32)
    a12 = models.IntegerField(initial=48)
    a20 = models.IntegerField(initial=24)
    a21 = models.IntegerField(initial=48)
    a22 = models.IntegerField(initial=72)

    paying_round = models.IntegerField(initial=-1)

    def creating_session(self):
        print("creating_session called for subsession.round_number=" + str(self.round_number))

        if self.round_number == 1:
            # create a map from round numbers to a boolean showing whether it's a paid round or not
            self.paying_round = random.randint(2, Constants.num_rounds)

        else:
            self.paying_round = self.in_previous_rounds()[0].paying_round

        # self.group_randomly()
        # groups subjects per round so that they are random but maintain their role
        players = self.get_players()
        a_players = []
        b_players = []
        if self.round_number == 1:
            matrix = self.get_group_matrix()
            for g in range(len(matrix)):
                for p in range(len(matrix[g])):
                    if p == 0 or p == 1 or p == 2:
                        a_players.append(matrix[g][p].participant.id_in_session)
                    if p == 3 or p == 4 or p == 5:
                        b_players.append(matrix[g][p].participant.id_in_session)
        else:
            matrix = self.session.get_subsessions()[0].get_group_matrix()
            for g in range(len(matrix)):
                for p in range(len(matrix[g])):
                    if p == 0 or p == 1 or p == 2:
                        a_players.append(matrix[g][p].participant.id_in_session)
                    if p == 3 or p == 4 or p == 5:
                        b_players.append(matrix[g][p].participant.id_in_session)

        list_of_lists = []
        random.shuffle(a_players)
        random.shuffle(b_players)
        for g in range(len(matrix)):
            index = 3 * g
            sublist = []
            sublist.append(a_players[index])
            sublist.append(a_players[index + 1])
            sublist.append(a_players[index + 2])
            sublist.append(b_players[index])
            sublist.append(b_players[index + 1])
            sublist.append(b_players[index + 2])
            list_of_lists.append(sublist)
        self.set_group_matrix(list_of_lists)
        self.save()

        for s in self.session.get_subsessions():
            print(" round " + str(s.round_number) + " matrix: " + str(s.get_group_matrix()))

        if 'decision_time_limit_seconds' in self.session.config:
            self.decision_time_limit_seconds = self.session.config['decision_time_limit_seconds']
        if 'response_time_limit_seconds' in self.session.config:
            self.response_time_limit_seconds = self.session.config['response_time_limit_seconds']

        if 'use_supermodular_matrix' in self.session.config and self.session.config['use_supermodular_matrix']==True:
            if self.round_number == 1:
                self.a00 = Constants.round_1_a00
                self.a01 = Constants.round_1_a01
                self.a02 = Constants.round_1_a02
                self.a10 = Constants.round_1_a10
                self.a11 = Constants.round_1_a11
                self.a12 = Constants.round_1_a12
                self.a20 = Constants.round_1_a20
                self.a21 = Constants.round_1_a21
                self.a22 = Constants.round_1_a22
            elif self.round_number == 2:
                self.a00 = Constants.round_2_a00
                self.a01 = Constants.round_2_a01
                self.a02 = Constants.round_2_a02
                self.a10 = Constants.round_2_a10
                self.a11 = Constants.round_2_a11
                self.a12 = Constants.round_2_a12
                self.a20 = Constants.round_2_a20
                self.a21 = Constants.round_2_a21
                self.a22 = Constants.round_2_a22
            elif self.round_number == 3:
                self.a00 = Constants.round_3_a00
                self.a01 = Constants.round_3_a01
                self.a02 = Constants.round_3_a02
                self.a10 = Constants.round_3_a10
                self.a11 = Constants.round_3_a11
                self.a12 = Constants.round_3_a12
                self.a20 = Constants.round_3_a20
                self.a21 = Constants.round_3_a21
                self.a22 = Constants.round_3_a22
            elif self.round_number == 4:
                self.a00 = Constants.round_4_a00
                self.a01 = Constants.round_4_a01
                self.a02 = Constants.round_4_a02
                self.a10 = Constants.round_4_a10
                self.a11 = Constants.round_4_a11
                self.a12 = Constants.round_4_a12
                self.a20 = Constants.round_4_a20
                self.a21 = Constants.round_4_a21
                self.a22 = Constants.round_4_a22
            elif self.round_number == 5:
                self.a00 = Constants.round_5_a00
                self.a01 = Constants.round_5_a01
                self.a02 = Constants.round_5_a02
                self.a10 = Constants.round_5_a10
                self.a11 = Constants.round_5_a11
                self.a12 = Constants.round_5_a12
                self.a20 = Constants.round_5_a20
                self.a21 = Constants.round_5_a21
                self.a22 = Constants.round_5_a22
            elif self.round_number == 6:
                self.a00 = Constants.round_6_a00
                self.a01 = Constants.round_6_a01
                self.a02 = Constants.round_6_a02
                self.a10 = Constants.round_6_a10
                self.a11 = Constants.round_6_a11
                self.a12 = Constants.round_6_a12
                self.a20 = Constants.round_6_a20
                self.a21 = Constants.round_6_a21
                self.a22 = Constants.round_6_a22
            elif self.round_number == 7:
                self.a00 = Constants.round_7_a00
                self.a01 = Constants.round_7_a01
                self.a02 = Constants.round_7_a02
                self.a10 = Constants.round_7_a10
                self.a11 = Constants.round_7_a11
                self.a12 = Constants.round_7_a12
                self.a20 = Constants.round_7_a20
                self.a21 = Constants.round_7_a21
                self.a22 = Constants.round_7_a22
            elif self.round_number == 8:
                self.a00 = Constants.round_8_a00
                self.a01 = Constants.round_8_a01
                self.a02 = Constants.round_8_a02
                self.a10 = Constants.round_8_a10
                self.a11 = Constants.round_8_a11
                self.a12 = Constants.round_8_a12
                self.a20 = Constants.round_8_a20
                self.a21 = Constants.round_8_a21
                self.a22 = Constants.round_8_a22
            elif self.round_number == 9:
                self.a00 = Constants.round_9_a00
                self.a01 = Constants.round_9_a01
                self.a02 = Constants.round_9_a02
                self.a10 = Constants.round_9_a10
                self.a11 = Constants.round_9_a11
                self.a12 = Constants.round_9_a12
                self.a20 = Constants.round_9_a20
                self.a21 = Constants.round_9_a21
                self.a22 = Constants.round_9_a22
            elif self.round_number == 10:
                self.a00 = Constants.round_10_a00
                self.a01 = Constants.round_10_a01
                self.a02 = Constants.round_10_a02
                self.a10 = Constants.round_10_a10
                self.a11 = Constants.round_10_a11
                self.a12 = Constants.round_10_a12
                self.a20 = Constants.round_10_a20
                self.a21 = Constants.round_10_a21
                self.a22 = Constants.round_10_a22
            elif self.round_number == 11:
                self.a00 = Constants.round_11_a00
                self.a01 = Constants.round_11_a01
                self.a02 = Constants.round_11_a02
                self.a10 = Constants.round_11_a10
                self.a11 = Constants.round_11_a11
                self.a12 = Constants.round_11_a12
                self.a20 = Constants.round_11_a20
                self.a21 = Constants.round_11_a21
                self.a22 = Constants.round_11_a22
        else:
            if self.round_number == 1:
                self.a00 = Constants.sub_round_1_a00
                self.a01 = Constants.sub_round_1_a01
                self.a02 = Constants.sub_round_1_a02
                self.a10 = Constants.sub_round_1_a10
                self.a11 = Constants.sub_round_1_a11
                self.a12 = Constants.sub_round_1_a12
                self.a20 = Constants.sub_round_1_a20
                self.a21 = Constants.sub_round_1_a21
                self.a22 = Constants.sub_round_1_a22
            elif self.round_number == 2:
                self.a00 = Constants.sub_round_2_a00
                self.a01 = Constants.sub_round_2_a01
                self.a02 = Constants.sub_round_2_a02
                self.a10 = Constants.sub_round_2_a10
                self.a11 = Constants.sub_round_2_a11
                self.a12 = Constants.sub_round_2_a12
                self.a20 = Constants.sub_round_2_a20
                self.a21 = Constants.sub_round_2_a21
                self.a22 = Constants.sub_round_2_a22
            elif self.round_number == 3:
                self.a00 = Constants.sub_round_3_a00
                self.a01 = Constants.sub_round_3_a01
                self.a02 = Constants.sub_round_3_a02
                self.a10 = Constants.sub_round_3_a10
                self.a11 = Constants.sub_round_3_a11
                self.a12 = Constants.sub_round_3_a12
                self.a20 = Constants.sub_round_3_a20
                self.a21 = Constants.sub_round_3_a21
                self.a22 = Constants.sub_round_3_a22
            elif self.round_number == 4:
                self.a00 = Constants.sub_round_4_a00
                self.a01 = Constants.sub_round_4_a01
                self.a02 = Constants.sub_round_4_a02
                self.a10 = Constants.sub_round_4_a10
                self.a11 = Constants.sub_round_4_a11
                self.a12 = Constants.sub_round_4_a12
                self.a20 = Constants.sub_round_4_a20
                self.a21 = Constants.sub_round_4_a21
                self.a22 = Constants.sub_round_4_a22
            elif self.round_number == 5:
                self.a00 = Constants.sub_round_5_a00
                self.a01 = Constants.sub_round_5_a01
                self.a02 = Constants.sub_round_5_a02
                self.a10 = Constants.sub_round_5_a10
                self.a11 = Constants.sub_round_5_a11
                self.a12 = Constants.sub_round_5_a12
                self.a20 = Constants.sub_round_5_a20
                self.a21 = Constants.sub_round_5_a21
                self.a22 = Constants.sub_round_5_a22
            elif self.round_number == 6:
                self.a00 = Constants.sub_round_6_a00
                self.a01 = Constants.sub_round_6_a01
                self.a02 = Constants.sub_round_6_a02
                self.a10 = Constants.sub_round_6_a10
                self.a11 = Constants.sub_round_6_a11
                self.a12 = Constants.sub_round_6_a12
                self.a20 = Constants.sub_round_6_a20
                self.a21 = Constants.sub_round_6_a21
                self.a22 = Constants.sub_round_6_a22
            elif self.round_number == 7:
                self.a00 = Constants.sub_round_7_a00
                self.a01 = Constants.sub_round_7_a01
                self.a02 = Constants.sub_round_7_a02
                self.a10 = Constants.sub_round_7_a10
                self.a11 = Constants.sub_round_7_a11
                self.a12 = Constants.sub_round_7_a12
                self.a20 = Constants.sub_round_7_a20
                self.a21 = Constants.sub_round_7_a21
                self.a22 = Constants.sub_round_7_a22
            elif self.round_number == 8:
                self.a00 = Constants.sub_round_8_a00
                self.a01 = Constants.sub_round_8_a01
                self.a02 = Constants.sub_round_8_a02
                self.a10 = Constants.sub_round_8_a10
                self.a11 = Constants.sub_round_8_a11
                self.a12 = Constants.sub_round_8_a12
                self.a20 = Constants.sub_round_8_a20
                self.a21 = Constants.sub_round_8_a21
                self.a22 = Constants.sub_round_8_a22
            elif self.round_number == 9:
                self.a00 = Constants.sub_round_9_a00
                self.a01 = Constants.sub_round_9_a01
                self.a02 = Constants.sub_round_9_a02
                self.a10 = Constants.sub_round_9_a10
                self.a11 = Constants.sub_round_9_a11
                self.a12 = Constants.sub_round_9_a12
                self.a20 = Constants.sub_round_9_a20
                self.a21 = Constants.sub_round_9_a21
                self.a22 = Constants.sub_round_9_a22
            elif self.round_number == 10:
                self.a00 = Constants.sub_round_10_a00
                self.a01 = Constants.sub_round_10_a01
                self.a02 = Constants.sub_round_10_a02
                self.a10 = Constants.sub_round_10_a10
                self.a11 = Constants.sub_round_10_a11
                self.a12 = Constants.sub_round_10_a12
                self.a20 = Constants.sub_round_10_a20
                self.a21 = Constants.sub_round_10_a21
                self.a22 = Constants.sub_round_10_a22
            elif self.round_number == 11:
                self.a00 = Constants.sub_round_11_a00
                self.a01 = Constants.sub_round_11_a01
                self.a02 = Constants.sub_round_11_a02
                self.a10 = Constants.sub_round_11_a10
                self.a11 = Constants.sub_round_11_a11
                self.a12 = Constants.sub_round_11_a12
                self.a20 = Constants.sub_round_11_a20
                self.a21 = Constants.sub_round_11_a21
                self.a22 = Constants.sub_round_11_a22

        for g in self.get_groups():
            g.init_states()
            for p in g.get_players():
                print("p.id_in_group=" + str(p.id_in_group) + ", role=" + str(
                    p.role()) + ", p.participant.id_in_session" + str(p.participant.id_in_session))

    def vars_for_admin_report(self):
        rval = {}

        rval['num_rounds'] = self.round_number
        print("(Subsession) len(self.in_all_rounds())==" + str(len(self.in_all_rounds())))
        for ss in self.in_all_rounds():
            gcount = 0
            for group in ss.get_groups():
                # unique_group_id = CellState.objects.filter(session_id=self.session.code)[0].group_id
                # group_transactions = Transaction.objects.filter(group__exact=unique_group_id).order_by("time").filter(round_number=group.round_number)
                group_transactions = Transaction.objects.filter(group__exact=group)
                print("trying to get transactions for group with session.code=" + str(
                    group.session.code) + ", numTransactions filtered=" + str(len(group_transactions)))
                tcount = 0
                for transaction in group_transactions:
                    rval['round.' + str(ss.round_number) + '.group.' + str(gcount) + '.num_transactions'] = len(
                        group_transactions)
                    rval.update(transaction.to_text(
                        'round.' + str(ss.round_number) + '.group.' + str(gcount) + '.transaction.' + str(
                            tcount) + '.'))
                    tcount = tcount + 1
                gcount = gcount + 1
            rval['num_groups'] = len(self.get_groups())
        return {
            'data_js_vars': json.dumps(rval)
        }


class Group(BaseGroup):
    time_set = models.BooleanField(initial=False)
    finished = models.BooleanField(initial=False)

    def init_states(self):
        print("init_states called... self.round_number=" + str(self.round_number))
        count = 0

        matrix_role_a = {
            Constants.type_a_names[0]: {
                Constants.type_b_names[0]: self.subsession.a00,
                Constants.type_b_names[1]: self.subsession.a01,
                Constants.type_b_names[2]: self.subsession.a02,
            },
            Constants.type_a_names[1]: {
                Constants.type_b_names[0]: self.subsession.a10,
                Constants.type_b_names[1]: self.subsession.a11,
                Constants.type_b_names[2]: self.subsession.a12,
            },
            Constants.type_a_names[2]: {
                Constants.type_b_names[0]: self.subsession.a20,
                Constants.type_b_names[1]: self.subsession.a21,
                Constants.type_b_names[2]: self.subsession.a22,
            },
        }
        matrix_role_b = {
            Constants.type_b_names[0]: {
                Constants.type_a_names[0]: Constants.b00,
                Constants.type_a_names[1]: Constants.b01,
                Constants.type_a_names[2]: Constants.b02,
            },
            Constants.type_b_names[1]: {
                Constants.type_a_names[0]: Constants.b10,
                Constants.type_a_names[1]: Constants.b11,
                Constants.type_a_names[2]: Constants.b12,
            },
            Constants.type_b_names[2]: {
                Constants.type_a_names[0]: Constants.b20,
                Constants.type_a_names[1]: Constants.b21,
                Constants.type_a_names[2]: Constants.b22,
            },
        }

        for a in Constants.type_a_names:
            for b in Constants.type_b_names:
                # print("trying to create state for a=" + str(a) + ", b=" + str(b))
                state = self.cellstate_set.create()
                state.type_a_name = a
                state.type_b_name = b
                state.a_pay = matrix_role_a[a][b]
                state.b_pay = matrix_role_b[b][a]
                state.session_id = self.session.code
                state.round_number = self.round_number
                state.save()
                print("saving state.  state.group_id=" + str(state.group_id) + ", state.round_number=" + str(
                    state.round_number))
                count = count + 1
                # print("... " + str(count) + " entries added to db with session_id=" + str(self.session.code))
                # self.decision_inactivity_time = timezone.now()

    def set_payoffs(self):
        for player in self.get_players():

            unique_group_id = CellState.objects.filter(session_id=self.session.code)[0].group_id
            print("group.session.code=" + str(self.session.code) + ", unique_group_id=" + str(
                unique_group_id) + ", player.group.round number=" + str(
                player.group.round_number) + ", self.round_number=" + str(self.round_number))
            # group_states = CellState.objects.filter(group__exact=player.group.id_in_subsession)
            # group_states = CellState.objects.filter(group__exact=self).filter(round_number=self.round_number)
            group_states = CellState.objects.filter(group__exact=self)
            print("new exact group object filter:  group_states.length=" + str(len(group_states)))
            if (player.type() == 'A'):
                own_states = group_states.filter(type_a_name=player.role()).filter(offer_accepted=True)
            else:
                own_states = group_states.filter(type_b_name=player.role()).filter(offer_accepted=True)
            if len(own_states) == 1:
                surplus = (own_states[0].a_pay + own_states[0].b_pay)
                split_offerer = own_states[0].offer_amount
                split_recipient = surplus - split_offerer
                if own_states[0].offerer == player.role():
                    player.potential_payoff = split_offerer
                    player.matched_to = own_states[0].recipient
                    player.match_surplus = surplus
                    player.split_self = split_offerer
                    player.split_other = split_recipient
                elif own_states[0].recipient == player.role():
                    player.potential_payoff = split_recipient
                    player.matched_to = own_states[0].offerer
                    player.match_surplus = surplus
                    player.split_self = split_recipient
                    player.split_other = split_offerer
            else:
                player.potential_payoff = 0
                player.matched_to = None
                player.match_surplus = None
                player.split_self = None
                player.split_other = None

        print("setting payoffs for player" + str(player.id_in_group) + ", len(own_matches)=" + str(
            len(own_states)) + ", potential_payoff=" + str(player.potential_payoff))
        print("setting payoffs: Subsession.paying_round=" + str(self.subsession.paying_round))
        if self.subsession.round_number == Constants.num_rounds:
            for player in self.get_players():
                player.payoff = player.in_round(self.subsession.paying_round).potential_payoff * 100


class Player(BasePlayer):
    matched_to = models.StringField()
    match_surplus = models.IntegerField()
    split_self = models.IntegerField()
    split_other = models.IntegerField()

    potential_payoff = models.CurrencyField(initial=0)

    def role(self):
        if self.id_in_group == 1:
            return Constants.type_a_names[0]
        if self.id_in_group == 2:
            return Constants.type_a_names[1]
        if self.id_in_group == 3:
            return Constants.type_a_names[2]
        if self.id_in_group == 4:
            return Constants.type_b_names[0]
        if self.id_in_group == 5:
            return Constants.type_b_names[1]
        if self.id_in_group == 6:
            return Constants.type_b_names[2]

    def type(self):

        if self.role() in Constants.type_a_names:
            print("player.type() called for player.id_in_group=" + str(self.id_in_group) + ", role()=" + str(
                self.role()) + ", returning A")
            return 'A'
        else:
            print("player.type() called for player.id_in_group=" + str(self.id_in_group) + ", role()=" + str(
                self.role()) + ", returning B")
            return 'B'

    def position(self):
        if self.type() == 'A':
            return self.id_in_group - 1
        elif self.type() == 'B':
            return self.id_in_group - 4

    done = models.BooleanField(initial=False)

    # def decision_time_left(self):
    #    #start = self.group.decision_inactivity_time
    #    now = timezone.now()


#        time_left = Constants.decision_time_limit_seconds - (now - start).seconds
#        print("start=" + str(start) + ", now=" + str(now) + ", time_left = " + str(time_left))
#        return time_left if time_left > 0 else 0


class CellState(Model):
    # each cell has a row and column name
    type_a_name = models.StringField()
    type_b_name = models.StringField()
    # each cell has a payoff for each row and column player
    a_pay = models.IntegerField()
    b_pay = models.IntegerField()
    # when an offer is made, one person is an offerer, the other the recipient
    offerer = models.StringField()
    recipient = models.StringField()
    # the amount the offer is for
    offer_amount = models.IntegerField()
    # whether the recipient has responded to the offer yet, or not
    offer_response_received = models.BooleanField(default=False)
    # the recipient's response
    offer_accepted = models.BooleanField()

    # creates a 1:m relation - each CellState belongs to a group, a group can have many CellStates
    group = ForeignKey(Group)

    session_id = models.StringField()
    round_number = models.IntegerField()

    def to_text(self, prefix):
        return {
            prefix + 'type_a_name': str(self.type_a_name),
            prefix + 'type_b_name': str(self.type_b_name),
            prefix + 'a_pay': str(self.a_pay),
            prefix + 'b_pay': str(self.b_pay),
            prefix + 'offerer': str(self.offerer),
            prefix + 'recipient': str(self.recipient),
            prefix + 'offer_amount': str(self.offer_amount),
            prefix + 'offer_response_received': str(self.offer_response_received),
            prefix + 'offer_accepted': str(self.offer_accepted),
            prefix + 'session_id': str(self.session_id),
            prefix + 'round_number': str(self.round_number),
        }


class Transaction(Model):
    # whether this is an offer, an accept, a reject, or a cancel
    type = models.StringField()

    offerer = models.IntegerField()
    offerer_name = models.StringField()

    receiver = models.IntegerField()
    receiver_name = models.StringField()

    amount = models.IntegerField()

    time = models.DateTimeField()

    group = ForeignKey(
        Group)  # creates a 1:m relation - each CellState belongs to a group, a group can have many CellStates
    session_id = models.StringField()
    round_number = models.IntegerField()

    def to_text(self, prefix):
        return {
            prefix + 'type': str(self.type),
            prefix + 'offerer': str(self.offerer),
            prefix + 'offerer_name': str(self.offerer_name),
            prefix + 'receiver': str(self.receiver),
            prefix + 'receiver_name': str(self.receiver_name),
            prefix + 'amount': str(self.amount),
            prefix + 'time': str(self.time),
            prefix + 'group': str(self.group),
            prefix + 'session_id': str(self.session_id),
            prefix + 'round_number': str(self.round_number),
        }
