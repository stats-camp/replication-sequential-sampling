from channels import Group
import json
from django.db import models
from matrix_matching.models import CellState
from matrix_matching.models import Constants
from otree.common import (
    channels_create_session_group_name, get_models_module
)
from django.utils import timezone
import datetime
from django.forms.models import model_to_dict

def decision_time_left(group_id):
    models_module = get_models_module('matrix_matching')
    group_object = models_module.Group.objects.get(id=group_id)

    time_left = group_object.subsession.decision_time_limit_seconds - (timezone.now() - group_object.subsession.decision_start_time).seconds
    # print("decision_time_left returning " + str(time_left))
    return time_left if time_left > 0 else 0


def ws_receive(message, params):
    # ASGI WebSocket packet-received and send-packet message types
    # both have a "text" key for their textual data.

    data = json.loads(message['text'])
    message_type = data['type']

    group_id, player_id, session_code = params.split(',')
    player_id = int(player_id)
    group_id = int(group_id)

    models_module = get_models_module('matrix_matching')

    group_object = models_module.Group.objects.get(id=group_id)
    player_object = group_object.get_player_by_id(player_id)
    print("ws_receive, received message, type=" + message_type + ", player_id=" + str(player_id) + ", group_id=" + str(
        group_id) + ", player_id=" + str(player_id) + ", group_object.round_number=" + str(group_object.round_number)+
          ", group_object.finished="+str(group_object.finished))
    print("")

    group_object.subsession.decision_start_time = timezone.now()
    group_object.subsession.save()
    if not group_object.finished and message_type == 'offer':
        print("row=" + data['row'] + ", col=" + data['col'] + ", offer=" + data['offer'])
        print("offerer=" + data['offerer'] + ", offerto=" + data['offerto'])

        # create a new transaction db entry
        transaction = group_object.transaction_set.create()
        transaction.type = 'offer'
        transaction.offerer_name = data['offerer']
        transaction.receiver_name = data['offerto']
        transaction.offerer = group_object.get_player_by_role(data['offerer']).id_in_group
        transaction.receiver = group_object.get_player_by_role(data['offerto']).id_in_group
        transaction.amount = data['offer']
        transaction.time = datetime.datetime.now()
        transaction.round_number = group_object.round_number
        transaction.save()

        if data['offerer'] in models_module.Constants.type_a_names:
            cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                round_number=group_object.round_number).filter(
                type_a_name=data['offerer']).filter(
                type_b_name=data['offerto'])
        else:
            cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                round_number=group_object.round_number).filter(
                type_a_name=data['offerto']).filter(
                type_b_name=data['offerer'])
        print("offer received cell_states.length=" + str(len(cell_states)))
        for state in cell_states:
            state.offerer = data['offerer']
            state.recipient = data['offerto']
            state.offer_amount = data['offer']
            state.save()

        Group(get_group_name(group_id, session_code)).send(
            {'text': json.dumps(
                {
                    'type': 'offer',
                    'row': data['row'],
                    'col': data['col'],
                    'offer': data['offer'],
                    'offerer': data['offerer'],
                    'offerto': data['offerto'],
                    'time': str(decision_time_left(group_id)),
                })}
        )


    elif not group_object.finished and message_type == 'offer_response':
        row = data['row']
        col = data['col']
        responder = data['response']
        offerer = data['offerer']
        offer = data['offer']
        response = data['response']
        print("row=" + data['row'] + ", col=" + data['col'] + ", offer=" + data['offer'] + ", response=" + data[
            'response'])
        models_module = get_models_module('matrix_matching')
        group_object = models_module.Group.objects.get(id=group_id)

        # if it's an accept we need to cancel things first
        if data['response'] == "accept":
            # first cancel all outstanding matches and offers that the offerer has
            if data['offerer'] in models_module.Constants.type_a_names:
                cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                    round_number=group_object.round_number).filter(
                    type_a_name=data['offerer']).exclude(type_b_name=data['offerto']).exclude(
                    offer_amount=None)
            else:
                cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                    round_number=group_object.round_number).filter(
                    type_b_name=data['offerer']).exclude(type_a_name=data['offerto']).exclude(
                    offer_amount=None)

            print("trying to cancel outstanding matches upon new match.  cell_states.size()==" + str(len(cell_states)))

            for state in cell_states:
                c_offer_amount = state.offer_amount
                c_offerer = state.offerer
                c_offerto = state.recipient
                print("canceling state with offerer = " + str(c_offerer) + " and recipient=" + str(
                    c_offerto) + " and offer_amount=" + str(c_offer_amount))
                Group(get_group_name(group_id, session_code)).send(
                    {'text': json.dumps(
                        {
                            'type': 'cancel',
                            'row': '-1',
                            'col': '-1',
                            'offer': str(c_offer_amount),
                            'offerer': str(c_offerer),
                            'offerto': str(c_offerto),
                            'time': str(decision_time_left(group_id)),
                        })}
                )

                # create a transaction for the autocancel
                transaction = group_object.transaction_set.create()
                transaction.type = "previous_match_autocancel"
                transaction.offerer_name = c_offerer
                transaction.receiver_name = c_offerto
                transaction.offerer = group_object.get_player_by_role(c_offerer).id_in_group
                transaction.receiver = group_object.get_player_by_role(c_offerto).id_in_group
                transaction.amount = c_offer_amount
                transaction.time = datetime.datetime.now()
                transaction.round_number = group_object.round_number
                transaction.save()

                state.offerer = None
                state.recipient = None
                state.offer_amount = None
                state.offer_accepted = None
                state.offer_response_received = None
                state.save()

            # next cancel all outstanding matches or offers that the recipient has
            if data['offerto'] in models_module.Constants.type_a_names:
                cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                    round_number=group_object.round_number).filter(
                    type_a_name=data['offerto']).exclude(type_b_name=data['offerer']).exclude(offer_amount=None)
            else:
                cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                    round_number=group_object.round_number).filter(
                    type_b_name=data['offerto']).exclude(type_a_name=data['offerer']).exclude(offer_amount=None)
            for state in cell_states:
                c_offer_amount = state.offer_amount
                c_offerer = state.offerer
                c_offerto = state.recipient
                Group(get_group_name(group_id, session_code)).send(
                    {'text': json.dumps(
                        {
                            'type': 'cancel',
                            'row': '-1',
                            'col': '-1',
                            'offer': str(c_offer_amount),
                            'offerer': str(c_offerer),
                            'offerto': str(c_offerto),
                            'time': str(decision_time_left(group_id)),
                        })}
                )

                # create a transaction for the autocancel
                transaction = group_object.transaction_set.create()
                transaction.type = "previous_match_autocancel"
                transaction.offerer_name = c_offerer
                transaction.receiver_name = c_offerto
                transaction.offerer = group_object.get_player_by_role(c_offerer).id_in_group
                transaction.receiver = group_object.get_player_by_role(c_offerto).id_in_group
                transaction.amount = c_offer_amount
                transaction.time = datetime.datetime.now()
                transaction.round_number = group_object.round_number
                transaction.save()

                state.offerer = None
                state.recipient = None
                state.offer_amount = None
                state.offer_accepted = None
                state.offer_response_received = None
                state.save()

            # then send out the accept
            Group(get_group_name(group_id, session_code)).send(
                {'text': json.dumps(
                    {
                        'type': 'offer_response',
                        'row': data['row'],
                        'col': data['col'],
                        'offer': data['offer'],
                        'offerer': data['offerer'],
                        'offerto': data['offerto'],
                        'response': data['response'],
                        'time': str(decision_time_left(group_id)),
                    })}
            )

        transaction = group_object.transaction_set.create()
        transaction.offerer_name = data['offerer']
        transaction.receiver_name = data['offerto']
        transaction.offerer = group_object.get_player_by_role(data['offerer']).id_in_group
        transaction.receiver = group_object.get_player_by_role(data['offerto']).id_in_group
        transaction.amount = data['offer']
        transaction.time = datetime.datetime.now()
        transaction.round_number = group_object.round_number
        # need to update the state of the table with the accepted or rejected
        if data['response'] == "accept":
            transaction.type = "accept"
            print("accept!")
        elif data['response'] == "reject" or data['response'] == "autoreject":
            transaction.type = data['response']
            print("reject!")
        transaction.save()

        # update the responded state with the accept or the reject
        if data['offerer'] in models_module.Constants.type_a_names:
            cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                round_number=group_object.round_number).filter(
                type_a_name=data['offerer']).filter(
                type_b_name=data['offerto'])
        else:
            cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                round_number=group_object.round_number).filter(
                type_a_name=data['offerto']).filter(
                type_b_name=data['offerer'])

        for state in cell_states:
            state.offer_response_received = True
            if data['response'] == "accept":
                state.offer_accepted = True
            else:
                state.offerer = None
                state.recipient = None
                state.offer_amount = None
                state.offer_accepted = None
                state.offer_response_received = None
            state.save()

        if data['response'] == "reject" or data['response'] == "autoreject":
            # send out the reject
            Group(get_group_name(group_id, session_code)).send(
                {'text': json.dumps(
                    {
                        'type': 'offer_response',
                        'row': data['row'],
                        'col': data['col'],
                        'offer': data['offer'],
                        'offerer': data['offerer'],
                        'offerto': data['offerto'],
                        'response': data['response'],
                        'time': str(decision_time_left(group_id)),
                    })}
            )

    elif not group_object.finished and message_type == 'cancel_match':
        row = data['row']
        col = data['col']
        responder = data['responder']
        offerer = data['offerer']
        offer = data['offer']
        canceler = data['canceler']
        print("CANCEL!  row=" + data['row'] + ", col=" + data['col'] + ", offer=" + data['offer'])

        models_module = get_models_module('matrix_matching')
        group_object = models_module.Group.objects.get(id=group_id)
        transaction = group_object.transaction_set.create()
        transaction.type = "cancel"
        transaction.offerer_name = data['offerer']
        transaction.receiver_name = data['responder']
        transaction.offerer = group_object.get_player_by_role(data['offerer']).id_in_group
        transaction.receiver = group_object.get_player_by_role(data['responder']).id_in_group
        transaction.amount = data['offer']
        transaction.time = datetime.datetime.now()
        transaction.round_number = group_object.round_number
        transaction.save()

        if data['offerer'] in models_module.Constants.type_a_names:
            cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                round_number=group_object.round_number).filter(
                type_a_name=data['offerer']).filter(
                type_b_name=data['responder'])
        else:
            cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                round_number=group_object.round_number).filter(
                type_a_name=data['responder']).filter(
                type_b_name=data['offerer'])
        print("offer received cell_states.length=" + str(len(cell_states)))
        for state in cell_states:
            state.offerer = None
            state.recipient = None
            state.offer_amount = None
            state.offer_response_received = False
            state.save()

            Group(get_group_name(group_id, session_code)).send(
                {'text': json.dumps(
                    {
                        'type': 'cancel',
                        'row': data['row'],
                        'col': data['col'],
                        'offer': data['offer'],
                        'offerer': data['offerer'],
                        'offerto': data['responder'],
                        'time': str(decision_time_left(group_id)),
                    })}
            )
    elif message_type == "finish":
        name = data['name']

        # calculate the payoff based on the matched cell or not
        models_module = get_models_module('matrix_matching')
        group_object = models_module.Group.objects.get(id=group_id)

        group_object.finished = True
        group_object.save()

        if data['name'] in models_module.Constants.type_a_names:
            cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                round_number=group_object.round_number).filter(
                type_a_name=data['name']).filter(
                offer_accepted=True)
            own_name = data['name']
            print("payoff for type a player " + own_name + ", cell_states.length=" + str(len(cell_states)))
            for i in range(len(cell_states)):
                print("cell " + str(i) + ": " + str(cell_states[i].to_text("cell." + str(i) + ".")))
            if len(cell_states) == 1:
                other_name = cell_states[0].recipient
                if cell_states[0].offerer == name:
                    own_pay = cell_states[0].offer_amount
                else:
                    own_pay = (cell_states[0].a_pay + cell_states[0].b_pay) - cell_states[0].offer_amount
            else:
                own_pay = 0
                other_name = "N/A"
        else:
            cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
                round_number=group_object.round_number).filter(
                type_b_name=data['name']).filter(
                offer_accepted=True)
            own_name = data['name']
            print("payoff for type b player " + own_name + ", cell_states.length=" + str(len(cell_states)))
            for i in range(len(cell_states)):
                print("cell " + str(i) + ": " + str(cell_states[i].to_text("cell." + str(i) + ".")))
            if len(cell_states) == 1:
                other_name = cell_states[0].offerer
                if cell_states[0].offerer == name:
                    own_pay = cell_states[0].offer_amount
                else:
                    own_pay = (cell_states[0].a_pay + cell_states[0].b_pay) - cell_states[0].offer_amount
            else:
                own_pay = 0
                other_name = "N/A"
        print("finish message received.  Sending payoff info.  cell_states.length==" + str(
            len(cell_states)) + ", other_name=" + str(other_name) + ", amount=" + str(own_pay))
        message.reply_channel.send(
            {'text': json.dumps(
                {
                    "type": "payoff",
                    "own_name": str(own_name),
                    "other_name": str(other_name),
                    "amount": str(own_pay),
                    "time": "N/A"
                }
            )
            }
        )


def ws_disconnect(message, params):
    print("ws_disconnect called.")

    # data = json.loads(message['text'])
    # message_type = data['type']

    group_id, player_id, session_code = params.split(',')

    # on a disconnect, we cancel any outstanding offer-responses that a player has
    models_module = get_models_module('matrix_matching')

    group_object = models_module.Group.objects.get(id=group_id)
    cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
        round_number=group_object.round_number).filter(
        recipient=group_object.get_player_by_id(player_id).role()).filter(
        offer_accepted=None
    )
    print("ws_disconnect, group_id=" + str(group_id) + ", player_id=" + str(player_id) + ", player role=" + str(
        group_object.get_player_by_id(player_id).role()) + ", cell_states.length=" + str(len(cell_states)))
    for state in cell_states:
        c_offerer = state.offerer
        c_recipient = state.recipient
        c_offer_amount = state.offer_amount
        state.offerer = None
        state.recipient = None
        state.offer_amount = None
        state.offer_response_received = False
        state.save()

        transaction = group_object.transaction_set.create()
        transaction.type = "disconnect_reject"
        transaction.offerer_name = c_offerer
        transaction.receiver_name = c_recipient
        transaction.offerer = group_object.get_player_by_role(c_offerer).id_in_group
        transaction.receiver = group_object.get_player_by_role(c_recipient).id_in_group
        transaction.amount = c_offer_amount
        transaction.time = datetime.datetime.now()
        transaction.round_number = group_object.round_number
        transaction.save()

        Group(get_group_name(group_id, session_code)).send(
            {'text': json.dumps(
                {
                    'type': 'offer_response',
                    'row': '-1',
                    'col': '-1',
                    'offer': str(c_offer_amount),
                    'offerer': str(c_offerer),
                    'offerto': str(c_recipient),
                    'response': "reject",
                    'time': str(decision_time_left(group_id)),
                })}
        )

    message.reply_channel.send({
        "text": "ws_disconnect",
    })


def get_group_name(group_id, sid):
    return "channel_matrix_matching_session-" + str(sid) + "_group-" + str(group_id)


def ws_add(message, params):
    print("ws_add called. params = " + params)
    group_id, player_id, session_code = params.split(',')
    player_id = int(player_id)
    group_id = int(group_id)

    # print("group name is: "+get_group_name(group_id, session_id))
    models_module = get_models_module('matrix_matching')
    group_object = models_module.Group.objects.get(id=group_id)

    print("session=" + str(session_code) + ", adding player with id=" + str(player_id))
    print("group_object=" + str(group_object) + ", round_number=" + str(group_object.round_number))

    group = Group(get_group_name(group_id, session_code))
    group.add(message.reply_channel)

    cell_states = CellState.objects.filter(session_id=session_code).filter(group__exact=group_id).filter(
        round_number=group_object.round_number)
    print("ws_add cell_states length: " + str(len(cell_states)))

    table_vars = get_table_vars(player_id, group_id, session_code, group_object.round_number)
    table_vars['type'] = 'state'

    if (group_object.time_set == False):
        group_object.time_set = True
        group_object.subsession.decision_start_time = timezone.now()
        group_object.save()
    table_vars['time'] = str(decision_time_left(group_id))

    message.reply_channel.send(
        {'text': json.dumps(table_vars)}
    )


def get_table_vars(id, gid, sid, rn):
    #print("get_table_vars() called with id=" + str(id) + ", group id=" + str(gid) + " and sid=" + str(sid))
    models_module = get_models_module('matrix_matching')
    group_object = models_module.Group.objects.get(id=gid)
    player = group_object.get_player_by_id(id)
    print("get_table_vars() called with id=" + str(id) + ", group id=" + str(gid) + " and sid=" + str(sid))
    print("get_table_vars() called, player.role()=="+str(player.role)+", player.id_in_group="+str(player.id_in_group)+", player.participant.id_in_session="+str(player.participant.id_in_session)+", player.type()="+str(player.type()))
    Constants = models_module.Constants
    rval = {
        'num_rows': str(3),
        'num_cols': str(3),
        'own_type': player.type(),
        'own_role': player.role(),
    }

    for n in range(len(Constants.type_a_names)):
        rval.update({'type_a_names_' + str(n): Constants.type_a_names[n], })
    for n in range(len(Constants.type_b_names)):
        rval.update({'type_b_names_' + str(n): Constants.type_b_names[n], })

    cell_states = CellState.objects.filter(session_id=sid).filter(group__exact=gid).filter(
        round_number=rn)
    print("session=" + str(sid) + ", round_number=" + str(player.group.round_number) + ", group=" + str(
        gid) + ", cell_states.length=" + str(len(cell_states)))
    for ta in range(len(Constants.type_a_names)):
        for tb in range(len(Constants.type_b_names)):
            # pass
            cell = cell_states.filter(type_a_name=Constants.type_a_names[ta]).filter(
                type_b_name=Constants.type_b_names[tb])
            # print("cell[0] is:  " + str(model_to_dict(cell[0])))
            # rval.update(model_to_dict(cell[0]))
            rval.update(
                cell[0].to_text("cell." + str(Constants.type_a_names[ta]) + "." + Constants.type_b_names[tb] + "."))
            # print("ta="+str(ta)+", tb="+str(tb)+", len(cell)="+str(len(cell)))
            # print("cell[0].type_a_name="+str(cell[0].type_a_name)+", cell[0].type_b_name="+str(cell[0].type_b_name))

    return rval
