# -*- coding: utf-8 -*-
from __future__ import division
from . import pages
from ._builtin import Bot
import random
from otree.common import Currency as c, currency_range
from .models import Constants

class PlayerBot(Bot):

    def play_round(self):

        # start game
        self.group.player_positions = '!!,A,W,A'
        print("BOT: self.group.player_positions="+str(self.group.player_positions))
        yield (pages.Decision)


    def validate_play(self):
        # basic assertions
        pass
