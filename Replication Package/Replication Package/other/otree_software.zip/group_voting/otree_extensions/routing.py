from django.conf.urls import url
from ..consumers import GroupVotingConsumer
from otree.channels.routing import websocket_routes


websocket_routes += [
    url(r'^group_voting/(?P<params>[\w,]+)/$',
        GroupVotingConsumer),
]

# Uncomment this line to print websocket_routes for troubleshooting
# print("websocket_routes="+str(websocket_routes))
