# -*- coding: utf-8 -*-
from __future__ import division
from . import models
from ._builtin import Page, WaitPage
from otree.common import Currency as c, currency_range
from .models import Constants
from django.utils import timezone
from statistics import median
import random
import csv
from math import floor
from otree.models_concrete import PageCompletion



class FirstWaitPage(WaitPage):
     wait_for_all_groups = True
     def after_all_players_arrive(self):
         # self.subsession.decision_start_time = timezone.now()
        pass


class DecisionWaitPage(WaitPage):
    def after_all_players_arrive(self):
        if self.subsession.use_static_sampling:
            self.group.set_static_payoffs()
        # self.subsession.decision_start_time = timezone.now()

    def is_displayed(self):
        return self.subsession.use_static_sampling


class StaticDecision(Page):
    form_model = 'player'
    form_fields = ['static_decision']

    def is_displayed(self):
        return self.subsession.use_static_sampling

    def vars_for_template(self):
        tmpls = {}
        d = None
        homogeneous = True
        for p in self.group.get_players():
            if d is None:
                d = p.discount
            else:
                if d != p.discount:
                    homogeneous = False
        tmpls['homogeneous_costs'] = homogeneous

        tmpls['triangle_discount'] = self.group.get_player_by_id(
            (self.player.id_in_group - 1 + 1) % Constants.players_per_group + 1).discount
        tmpls['square_discount'] = self.group.get_player_by_id(
            (self.player.id_in_group - 1 + 2) % Constants.players_per_group + 1).discount

        tmpls['self_va'] = self.player.v_a
        tmpls['self_vb'] = self.player.v_a

        tmpls['triangle_va'] = self.group.get_player_by_id(
            (self.player.id_in_group - 1 + 1) % Constants.players_per_group + 1).v_a
        tmpls['triangle_vb'] = self.group.get_player_by_id(
            (self.player.id_in_group - 1 + 1) % Constants.players_per_group + 1).v_b

        tmpls['square_va'] = self.group.get_player_by_id(
            (self.player.id_in_group - 1 + 2) % Constants.players_per_group + 1).v_a
        tmpls['square_vb'] = self.group.get_player_by_id(
            (self.player.id_in_group - 1 + 2) % Constants.players_per_group + 1).v_b

        d = None
        homogeneous = True
        for p in self.group.get_players():
            if d is None:
                d = p.discount
            else:
                if d != p.discount:
                    homogeneous = False
        tmpls['homogeneous_costs'] = homogeneous

        return tmpls

    def before_next_page(self):
        print("StaticDecision: before_next_page called.");
        if self.subsession.use_individual_decision:
            print("self.timeout_happened="+str(self.timeout_happened))
            for p in self.subsession.get_players():
                print("p.id_in_group="+str(p.id_in_group)+", p.static_decision="+str(p.static_decision))
            if self.timeout_happened:
                val = random.randint(0,60)
                print("timeout happened, random choice is: "+str(val))
                self.player.static_decision = val
        else:
            if self.timeout_happened:
                self.player.static_decision = None



class Decision(Page):
    # timeout_seconds = 180
    form_model = 'player'
    form_fields = []

    # def vars_for_template(self):
    #     return {'player_id': self.player.id_in_group,
    #             'rowAcolumnA_row': Constants.rowAcolumnA_row,
    #             'rowAcolumnA_column': Constants.rowAcolumnA_column,
    #             'rowAcolumnB_row': Constants.rowAcolumnB_row,
    #             'rowAcolumnB_column': Constants.rowAcolumnB_column,
    #             'rowBcolumnA_row': Constants.rowBcolumnA_row,
    #             'rowBcolumnA_column': Constants.rowBcolumnA_column,
    #             'rowBcolumnB_row': Constants.rowBcolumnB_row,
    #             'rowBcolumnB_column': Constants.rowBcolumnB_column}

    def vars_for_template(self):
        # print("self.session.id="+str(self.session.code))
        # print("self.group.id="+str(self.group.id))
        #unique_group_id=CellState.objects.filter(session_id=self.session.code).filter(round_number=self.round_number)[0].group_id
        tmpls = {
            'session_code': str(self.session.code),
            'group_id': str(self.group.id),
            'id_in_group': str(self.player.id_in_group),
            'id_in_session': str(self.player.participant.id_in_session),
            # 'group'
            'name': str(self.player.role()),
            'round_number': str(self.round_number),
            # 'response_time_limit_seconds': str(self.subsession.response_time_limit_seconds),
            # "time_left": self.player.decision_time_left(),
            'v_a': self.player.v_a,
            'state': self.subsession.state,
            'decision': '',
        }

        # read in the answers to the sums
        with open('group_voting/static/input_data.csv') as f:
            processes = list(csv.reader(f))
        num_processes = len(processes)
        for i in range(len(processes)):
            # print("processes["+str(i)+"]="+str(processes[i]))

            for j in range(len(processes[i])):
                processes[i][j] = float(processes[i][j])

        tmpls['process'] = processes[self.subsession.process_number]

        if self.subsession.use_static_sampling:

            if self.subsession.use_individual_decision:
                tmpls['static_time'] = int(self.player.static_decision)
                tmpls['decision'] = self.player.individual_decision
            else:
                tmpls['static_time'] = int(self.group.group_static_decision)
                tmpls['decision'] = self.group.group_decision
        else:
            tmpls['static_time'] = -1
        # print("vars_for_template returning (for id_in_group="+str(self.player.id_in_group)+" with name="+str(tmpls['name']))

        d = None
        homogeneous = True
        for p in self.group.get_players():
            if d is None:
                d = p.discount
            else:
                if d != p.discount:
                    homogeneous = False
        tmpls['homogeneous_costs'] = homogeneous

        tmpls['triangle_discount'] = self.group.get_player_by_id(
            (self.player.id_in_group - 1 + 1) % Constants.players_per_group + 1).discount
        tmpls['square_discount'] = self.group.get_player_by_id(
            (self.player.id_in_group - 1 + 2) % Constants.players_per_group + 1).discount

        if self.subsession.use_static_sampling:
            tmpls['self_static_decision'] = str(self.player.static_decision)
            tmpls['triangle_static_decision'] = str(self.group.get_player_by_id(
                (self.player.id_in_group - 1 + 1) % Constants.players_per_group + 1).static_decision)
            tmpls['square_static_decision'] = str(self.group.get_player_by_id(
                (self.player.id_in_group - 1 + 2) % Constants.players_per_group + 1).static_decision)

        return tmpls

    def before_next_page(self):
        print("Decision: before_next_page called for player.id_in_group="+str(self.player.id_in_group)+".");
        if self.subsession.use_static_sampling:
            pass
        else:
            # for p in self.subsession.get_players():
            #     print("p.id_in_group="+str(p.id_in_group)+", move_values="+str(p.move_values)+", move_clicks="+str(p.move_clicks))
            if self.timeout_happened:

                if self.subsession.use_individual_decision:
                    print("self.group.player_positions="+str(self.group.player_positions))
                    current_move = self.group.player_positions.split(",")[self.player.id_in_group]
                    print("current_move="+str(current_move))
                    if current_move == 'W':
                        current_time = timezone.now()
                        print("current_time=" + str(current_time) + ", decision_start_time=" + str(
                            self.group.decision_start_time))
                        time_delta_milliseconds = (current_time - self.group.decision_start_time).total_seconds() * 1000
                        print("time_delta_milliseconds=" + str(time_delta_milliseconds))
                        current_click = floor(time_delta_milliseconds / self.subsession.tick_interval_milliseconds)
                        print("current_click=" + str(current_click))
                        self.player.move_clicks = ',' + str(current_click)

                        if random.random() > 0.5:
                            self.player.move_values = ',A'
                            move = 'A'
                        else:
                            self.player.move_values = ',B'
                            move = 'B'
                else:
                    move = 'W'

                    if self.player.move_values is None:
                        print("self.player.move_values is NONE!")
                    elif self.player.move_values == '':
                        print("self.player.move_values is EMPTY")
                    else:
                        move = self.player.move_values.split(',')[-1]
                    move_list = self.group.player_positions.split(',')
                    move_list[self.player.id_in_group] = move
                    print("old move_list is: "+str(self.group.player_positions)+", new move_list is: "+str(move_list))
                    self.group.player_positions = ','.join(map(str, move_list))





class ResultsWaitPage(WaitPage):
    def after_all_players_arrive(self):
        if not self.subsession.use_static_sampling:
            self.group.set_payoffs()

page_sequence = [FirstWaitPage,
                 StaticDecision,
                 DecisionWaitPage,
                 Decision,
                 ResultsWaitPage,
                 ]
